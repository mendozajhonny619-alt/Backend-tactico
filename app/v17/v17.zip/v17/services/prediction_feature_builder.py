from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(float(value))
    except Exception:
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        try:
            return float(str(value).replace(',', '.'))
        except Exception:
            return default


def bool_to_int(value: Any) -> int:
    return 1 if bool(value) else 0


def normalize_market(market: Any) -> str:
    text = str(market or "").upper()
    if "OVER" in text:
        return "OVER"
    if "UNDER" in text:
        return "UNDER"
    if "SOBRE" in text:
        return "OVER"
    if "BAJO" in text:
        return "UNDER"
    return "OTHER"


class PredictionFeatureBuilder:
    """
    Construye un feature vector estable para predicción y análisis posterior.

    La oferta de la Fase 2 es infraestructura paralela: guardamos features
    para análisis sin tocar la lógica operativa de V17.
    """

    def build(
        self,
        match: Dict[str, Any],
        pre_match_profile: Dict[str, Any],
        context: Dict[str, Any],
        tactical: Dict[str, Any],
        market: Dict[str, Any],
        risk: Dict[str, Any],
        clock: Dict[str, Any],
        data_quality: Dict[str, Any],
    ) -> Dict[str, Any]:
        fixture_id = str(match.get("fixture_id") or match.get("match_id") or "").strip()
        api_minute = safe_int(match.get("api_minute") or match.get("display_minute") or match.get("minute"), 0)
        market_direction = normalize_market(market.get("suggested_market") or market.get("market") or market.get("master_market"))

        # Competition intelligence comes from LeagueFilter / LiveSnapshotStore.
        # Defaults are conservative so this remains backwards-compatible with old payloads.
        competition_tier = str(match.get("competition_tier") or "UNKNOWN").upper()
        competition_weight = safe_float(match.get("competition_weight"), 0.0)
        league_filter_status = str(match.get("league_filter_status") or "")
        world_cup_flag = bool_to_int(match.get("world_cup_flag") or competition_tier == "WORLD_CUP_ELITE")
        national_team_flag = bool_to_int(match.get("national_team_flag") or competition_tier in {
            "WORLD_CUP_ELITE",
            "NATIONAL_TEAM_ELITE",
        })
        major_tournament_flag = bool_to_int(match.get("major_tournament_flag") or competition_tier in {
            "WORLD_CUP_ELITE",
            "INTERNATIONAL_CLUB_ELITE",
            "NATIONAL_TEAM_ELITE",
        })

        feature_vector = {
            # base match state
            "minute": api_minute,
            "home_score": safe_int(match.get("home_score"), 0),
            "away_score": safe_int(match.get("away_score"), 0),
            "total_goals": safe_int(match.get("home_score"), 0) + safe_int(match.get("away_score"), 0),
            "score_diff": abs(safe_int(match.get("home_score"), 0) - safe_int(match.get("away_score"), 0)),
            "is_draw": bool_to_int(match.get("home_score") == match.get("away_score")),
            "market_over": bool_to_int(market_direction == "OVER"),
            "market_under": bool_to_int(market_direction == "UNDER"),
            "market_other": bool_to_int(market_direction == "OTHER"),

            # competition intelligence V17
            "competition_weight": competition_weight,
            "world_cup_flag": world_cup_flag,
            "national_team_flag": national_team_flag,
            "major_tournament_flag": major_tournament_flag,
            "competition_tier_world_cup_elite": bool_to_int(competition_tier == "WORLD_CUP_ELITE"),
            "competition_tier_international_club_elite": bool_to_int(competition_tier == "INTERNATIONAL_CLUB_ELITE"),
            "competition_tier_national_team_elite": bool_to_int(competition_tier == "NATIONAL_TEAM_ELITE"),
            "competition_tier_priority_league": bool_to_int(competition_tier == "PRIORITY_LEAGUE"),
            "competition_tier_country_review": bool_to_int(competition_tier == "COUNTRY_REVIEW"),

            # context reader
            "goal_need_score": safe_float(context.get("goal_need_score"), 0.0),
            "pressure_score": safe_float(context.get("pressure_score"), 0.0),
            "rhythm_score": safe_float(context.get("rhythm_score"), 0.0),
            "over_context_score": safe_float(context.get("over_context_score"), 0.0),
            "under_context_score": safe_float(context.get("under_context_score"), 0.0),
            "score_hold_probability": safe_float(context.get("score_hold_probability"), 0.0),
            "under_transition_score": safe_float(context.get("under_transition_score"), 0.0),
            "conmebol_late": bool_to_int(context.get("conmebol_late")),
            "is_conmebol": bool_to_int(context.get("is_conmebol")),

            # tactical AI
            "tactical_score": safe_float(tactical.get("tactical_score"), 0.0),
            "deep_pressure_score": safe_float(tactical.get("deep_pressure_score"), 0.0),
            "offensive_depth_score": safe_float(tactical.get("offensive_depth_score"), 0.0),
            "offensive_volume_score": safe_float(tactical.get("offensive_volume_score"), 0.0),
            "recent_attack_proxy": safe_float(tactical.get("recent_attack_proxy"), 0.0),
            "false_pressure_risk": safe_float(tactical.get("false_pressure_risk"), 0.0),
            "tactical_warnings_count": len(tactical.get("tactical_warnings") or []),
            "tactical_strengths_count": len(tactical.get("tactical_strengths") or []),

            # market AI
            "over_score": safe_float(market.get("over_score"), 0.0),
            "under_score": safe_float(market.get("under_score"), 0.0),
            "market_confidence": safe_float(market.get("market_confidence"), 0.0),
            "market_gap": safe_float(market.get("market_gap"), 0.0),
            "offensive_volume_support": safe_float(market.get("offensive_volume_score"), 0.0),
            "suggested_market_over": bool_to_int(normalize_market(market.get("suggested_market")) == "OVER"),
            "suggested_market_under": bool_to_int(normalize_market(market.get("suggested_market")) == "UNDER"),

            # risk AI
            "risk_score": safe_float(risk.get("risk_score"), 0.0),
            "hard_blockers_count": len(risk.get("hard_blockers") or []),
            "risk_reasons_count": len(risk.get("risk_reasons") or []),
            "risk_warnings_count": len(risk.get("risk_warnings") or []),
            "risk_action_observe": bool_to_int(str(risk.get("risk_action") or "").upper() == "OBSERVE"),
            "risk_action_block": bool_to_int(str(risk.get("risk_action") or "").upper() == "BLOCK"),
        }

        # pre-match support structure
        feature_vector.update(
            {
                "pre_match_available": bool_to_int(pre_match_profile.get("pre_match_available")),
                "over_pre_match_score": safe_float(pre_match_profile.get("over_pre_match_score"), 0.0),
                "under_pre_match_score": safe_float(pre_match_profile.get("under_pre_match_score"), 0.0),
                "over_support_pre_match": safe_float(pre_match_profile.get("over_support_pre_match"), 0.0),
                "under_support_pre_match": safe_float(pre_match_profile.get("under_support_pre_match"), 0.0),
                "pre_match_caution_points_count": len(pre_match_profile.get("pre_match_caution_points") or []),
                "pre_match_support_points_count": len(pre_match_profile.get("pre_match_support_points") or []),
            }
        )

        metadata = {
            "fixture_id": fixture_id,
            "match_id": str(match.get("match_id") or ""),
            "league": str(match.get("league") or ""),
            "country": str(match.get("country") or ""),
            "competition_tier": competition_tier,
            "competition_weight": competition_weight,
            "world_cup_flag": world_cup_flag,
            "national_team_flag": national_team_flag,
            "major_tournament_flag": major_tournament_flag,
            "league_filter_status": league_filter_status,
            "league_filter_reason": str(match.get("league_filter_reason") or ""),
            "home_team": str(match.get("home_team") or ""),
            "away_team": str(match.get("away_team") or ""),
            "market_direction": market_direction,
            "market_category": str(market.get("market_category") or ""),
            "market_status": str(market.get("market_status") or ""),
            "risk_status": str(risk.get("risk_status") or ""),
            "risk_action": str(risk.get("risk_action") or ""),
            "pre_match_profile_version": str(pre_match_profile.get("pre_match_profile_version") or ""),
            "event_time": utc_now_iso(),
            "clock_can_enter": bool_to_int(clock.get("clock_can_enter")),
            "data_valid": bool_to_int(data_quality.get("data_valid")),
            "data_quality": str(data_quality.get("data_quality") or ""),
            "data_age_seconds": safe_int(match.get("data_age_seconds"), 0),
        }

        return {
            "fixture_id": fixture_id,
            "api_minute": api_minute,
            "event_time": utc_now_iso(),
            "feature_vector": feature_vector,
            "metadata": metadata,
            "match_snapshot": self._clean_snapshot(match),
            "pre_match_snapshot": self._clean_snapshot(pre_match_profile),
            "context_snapshot": self._clean_snapshot(context),
            "tactical_snapshot": self._clean_snapshot(tactical),
            "market_snapshot": self._clean_snapshot(market),
            "risk_snapshot": self._clean_snapshot(risk),
            "prediction_snapshot": {},
        }

    def _clean_snapshot(self, snapshot: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not isinstance(snapshot, dict):
            return {}
        return {
            key: self._serialize_value(value)
            for key, value in snapshot.items()
            if self._is_serializable(value)
        }

    def _is_serializable(self, value: Any) -> bool:
        return isinstance(value, (str, int, float, bool, list, dict)) or value is None

    def _serialize_value(self, value: Any) -> Any:
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        try:
            return json.loads(json.dumps(value, default=str))
        except Exception:
            return str(value)